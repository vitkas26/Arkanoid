package com.example.arkanoidchristmas

enum class Direction{
    RIGHT,
    LEFT,
}